# Acquired-feature research experiment

Status: awaiting_data. Evidence: real.
Experiment: sha256:680b75fdc0cd4f8d2257238f66d11b1cf4dfbd43cf5219ec748c002260626930

0 independent training events with labels available before cutoff < 30; late receipts cannot be backdated. A longer window of timely, independent labeled events is required

Model scores: {}

Executable backtest: {"eligible": false, "executed": false, "execution_fidelity": "predictive_only", "paper_eligible": false, "performance": null, "prospective_validation": "pending_genuine_forward_observations", "reasons": ["Historical decision-time contract prices and sized order books are unavailable.", "Contract rules known at historical decision times are unverified.", "Frozen point-in-time contract probabilities are unavailable; scalar predictive metrics are not trading probabilities.", "Certified applicable historical fee evidence is unavailable."], "status": "awaiting_execution_evidence", "strategy": null, "submission_enabled": false}

Historical replay only; generated historical predictions are never prospective.
Temperature-threshold scores are predictive analysis, not contract returns.
All requested model families and previous searches count toward selection effects.
Intervals are descriptive after model search; no strategy promotion is authorized.
Protected holdout outcomes are not scored or used to fit/calibrate models.
