# Acquired-feature research experiment

Status: unsupported. Evidence: real.
Experiment: sha256:797449e11cce72ebb482b81897429a5505ad8904acb2e2b36f2d9caa596ab0fb

Feature is not materialized by the acquired-data adapter: forecast_provider_disagreement
Unsupported role/type/unit for weather modeling: market_implied_probability
Feature is not materialized by the acquired-data adapter: market_implied_probability
Weather modeling requires a registered point-in-time forecast level

Model scores: {}

Executable backtest: {"eligible": false, "executed": false, "execution_fidelity": "predictive_only", "paper_eligible": false, "performance": null, "prospective_validation": "pending_genuine_forward_observations", "reasons": ["Historical decision-time contract prices and sized order books are unavailable.", "Contract rules known at historical decision times are unverified.", "Frozen point-in-time contract probabilities are unavailable; scalar predictive metrics are not trading probabilities.", "Certified applicable historical fee evidence is unavailable."], "status": "awaiting_execution_evidence", "strategy": null, "submission_enabled": false}

Historical replay only; generated historical predictions are never prospective.
Temperature-threshold scores are predictive analysis, not contract returns.
All requested model families and previous searches count toward selection effects.
Intervals are descriptive after model search; no strategy promotion is authorized.
Protected holdout outcomes are not scored or used to fit/calibrate models.
