# Research-to-experiment report

Data: real. Research run: 3a7bb44e-c0cc-47bf-beae-d05ee9e923e7
Final holdout: not evaluated. No trading authorization.

template-c0: INSUFFICIENT_DATA
required source provenance is unavailable at decision time
template-c1: INSUFFICIENT_DATA
required source provenance is unavailable at decision time

Each candidate/scenario counts as a trial. Intervals are descriptive after selection.
Snapshot fills model taker execution, not queues or observed fills.
Synthetic results verify software only; ranking is not deployment authorization.
